(function() {
  $(".menu").click(function() {
    return $(".mobile-navigation").slideToggle("fast");
  });

}).call(this);
