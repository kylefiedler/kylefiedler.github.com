(function() {
  $(".menu").click(function() {
    $(".main-navigation").slideToggle("fast");
    return false;
  });

}).call(this);
